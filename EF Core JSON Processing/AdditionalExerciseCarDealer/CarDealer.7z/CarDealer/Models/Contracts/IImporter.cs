﻿namespace CarDealer.Models.Contracts
{
    public interface IImporter
    {
        void Import();
    }
}
