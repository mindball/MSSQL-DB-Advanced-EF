﻿namespace CarDealer.Models.Contracts
{
    public interface IExporter
    {
        void Export();
    }
}
