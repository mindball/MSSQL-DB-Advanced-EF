﻿namespace CarDealer.Models.Import
{
    using CarDealer.Models.Contracts;
    using CarDealer.Models;

    public abstract class Importer : IImporter
    {
        
        public void Import()
        {
            throw new System.NotImplementedException();
        }
    }
}
